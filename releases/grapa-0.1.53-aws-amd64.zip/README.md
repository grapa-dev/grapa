# Grapa 0.1.53 - AWS AMD64

This package contains Grapa for AWS AMD64.

## Quick Start

1. **Install Grapa:**
   ```bash
   python3 install-grapa.py
   ```

2. **Build and run the example:**
   ```bash
   mkdir build && cd build
   cmake ..
   cmake --build .
   ./grapa_example
   ```

3. **Install Python extension:**
   ```bash
   pip install grapapy==0.1.53
   ```

## What's Included

- Grapa executable and libraries for AWS AMD64
- Universal installer script
- Sample C++ application with CMake build system
- Headers and development files
- Legal documentation

## Universal Installer

The `install-grapa.py` script automatically:
- Detects your platform
- Installs Grapa to the correct location
- Sets up environment variables
- Creates symbolic links

## Support

For more information, visit: https://grapa.dev
